
# IC05 - Etude comportementale sur le web

Installer l'extension
1. chrome://extensions/
2. Mode développeur
3. Charger le dossier avec l'extension
4. Cliquer sur l'extension dans le menu Chrome

---

Pour Firefox:

* Installer *web-ext* avec npm : https://github.com/mozilla/web-ext
* Ouvrir un terminal dans le dossier de l'extension et lancer : 
```bash
$ web-ext run
```
L'extension se recharge automatiquement lorsque le code est modifié (super pratique !)
